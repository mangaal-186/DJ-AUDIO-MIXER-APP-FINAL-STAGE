import * as React from 'react';
import { View, StyleSheet, Text } from 'react-native';


class AppHeader extends React.Component{
  render(){
    return(
      <View style = {head.container}>
        <Text style = {head.text}>  
          DJ App
        </Text>
      </View>
    )
  }

}

const head = StyleSheet.create({
    container: {alignItems: 'center', backgroundColor: 'gray', borderWidth: 2, borderColor: 'blue', borderBottomWidth: 0},
    text: {textAlign: 'center', color: 'orange', fontSize: 40, fontWeight: 'bold'}

})

export default AppHeader