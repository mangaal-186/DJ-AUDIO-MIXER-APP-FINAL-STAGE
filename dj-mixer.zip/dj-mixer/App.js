import React, { Component } from 'react';
import { Button, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import {Audio} from 'expo-av';
import AppHeader from './components/AppHeader'
class Button1 extends Component {
  displayAlert = () => {
    alert('Music 1');
  };
  playSound = async () => {
     await Audio.Sound.createAsync({uri:'http://soundbible.com/mp3/Buzzer-SoundBible.com-188422102.mp3'}, {shouldPlay: 'true'})
  }
  render() {
    return (
      <Button color="black" title="Bass Beat 1" onPress={this.playSound}/>
    );
  }
}

class Button2 extends Component {
  displayAlert = () => {
    alert('Music 2');
  };
  playSound = async () => {
     await Audio.Sound.createAsync({uri:'http://soundbible.com/mp3/Buzzer-SoundBible.com-188422102.mp3'}, {shouldPlay: 'true'})
  }
  render() {
    return (
      <Button title="Bass Beat 2" color="black" onPress={this.playSound} />
    );
  }
}

class Button3 extends Component {
  displayAlert = () => {
    alert('Music 3');
  };
  playSound = async () => {
     await Audio.Sound.createAsync({uri:'http://soundbible.com/mp3/Buzzer-SoundBible.com-188422102.mp3'}, {shouldPlay: 'true'})
  }
  render() {
    return <Button title="Techno 1" color="darkgrey" onPress={this.playSound} />;
  }
}

class Button4 extends Component {
  displayAlert = () => {
    alert('Music 4');
  };
  playSound = async () => {
     await Audio.Sound.createAsync({uri:'https://d1490khl9dq1ow.cloudfront.net/audio/music/mp3preview/BsTwCwBHBjzwub4i4/rock-guitar-music-bed_z1y16Brd_NWM.mp3'}, {shouldPlay: 'true'})
  }
  render() {
    return <Button title="Rock 1" color="blue" onPress={this.playSound} />;
  }
}

class Button5 extends Component {
  displayAlert = () => {
    alert('Music 5');
  };
  playSound = async () => {
     await Audio.Sound.createAsync({uri:'https://d1490khl9dq1ow.cloudfront.net/audio/music/mp3preview/BsTwCwBHBjzwub4i4/bright-and-breezy-music-bed_MJA8hSHO_NWM.mp3'}, {shouldPlay: 'true'})
  }
  render() {
    return <Button title="Jazz 1" color='cyan' onPress={this.playSound} />;
  }
}

class Button6 extends Component {
  displayAlert = () => {
    alert('Music 6');
  };
  playSound = async () => {
     await Audio.Sound.createAsync({uri:'http://soundbible.com/mp3/Buzzer-SoundBible.com-188422102.mp3'}, {shouldPlay: 'true'})
  }
  render() {
    return <Button title="Jazz 2" color='cyan' onPress={this.playSound} />;
  }
}

class Button7 extends Component {
  displayAlert = () => {
    alert('Music 7');
  };
  playSound = async () => {
     await Audio.Sound.createAsync({uri:'http://soundbible.com/mp3/Buzzer-SoundBible.com-188422102.mp3'}, {shouldPlay: 'true'})
  }
  render() {
    return <Button title="Pop 1" color="red" onPress={this.playSound} />;
  }
}

class Button8 extends Component {
  displayAlert = () => {
    alert('Stop');
  };
  render() {
    return <Button title="Stop All Music" color="black" onPress={this.displayAlert} />;
  }
}
export default class App extends Component {
  render() {
    return (
      <View> <AppHeader />
        <View style={styles.back}>
          <Button1 />
          <View style={styles.back}>
            <Button2 />
            <View style={styles.back}>
              <Button3 />
              <View style={styles.back}>
                <Button4 />
                <View style={styles.back}>
                  <Button5 />
                  <View style={styles.back}>
                    <Button6 />
                    <View style={styles.back}>
                      <Button7 />
                      <View style={styles.back}>
                        <Button8 />
                    </View>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>
      </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
    back: {alignItems: 'center', backgroundColor: 'gray', marginTop: 30, borderLeftWidth: 3, borderRightWidth: 3, borderLeftColor: 'blue', borderRightColor: 'blue'}
})

